/*******************************************************************************
* Created by: Matthew Brean
* Created on: 2016-09-22
* Created for: ICS4U
* Daily Assignment: Unit #1-09
* This program calculates average based on 4x6 student x marks array
*******************************************************************************/

import java.util.Scanner;
import java.util.Random;


public class MarkAverage {



        public static void main(String[] args) {
                Random rand = new Random();


        // declares an array of integers
        int[][] anArray = new int [4][6]; //creates 2d array (4x6)


        int columnCounter = 0;
        int rowCounter = 0;
        //int randomNumber;
        int addingAllNumbers = 0;
        int currentRandomNumber = 0;

        while (rowCounter < 6){

        while (columnCounter < 4){

        currentRandomNumber = rand.nextInt(100) + 0; //0-100 generate #
                anArray[columnCounter][rowCounter] = currentRandomNumber;

                addingAllNumbers = addingAllNumbers + currentRandomNumber;

                System.out.println(anArray[columnCounter][rowCounter]);
                columnCounter++;
        }
        columnCounter = 0;
        rowCounter++;

        }

        System.out.println();
        System.out.println("#######");
        System.out.println();
        //System.out.println("");
        System.out.println("Sum: "+addingAllNumbers);
        System.out.println();
        System.out.println("Average: "+ addingAllNumbers/24);

        }

}
